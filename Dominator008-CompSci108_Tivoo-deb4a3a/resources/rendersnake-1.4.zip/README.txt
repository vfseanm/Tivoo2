Release 1.1 of 2011-04-29

Notes
  http://code.google.com/p/rendersnake/wiki/ReleaseNotes

Web
  http://rendersnake.org

Project
  http://code.google.com/p/rendersnake/

Blog
  http://philemonworks.wordpress.com
  
Maven Installation
  http://code.google.com/p/rendersnake/wiki/MavenInstallationAndUse
  
Sources
  http://code.google.com/p/rendersnake/source/checkout
  
License
  http://www.apache.org/licenses/LICENSE-2.0
  
Who
  ernest [dot] micklei [at] gmail [dot] com  (owner)
  wfe [dot] dehaan [at] gmail [dot] com  (committer)
   

